using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour
{
    public int health = 50;
    public int damage = 20;
    public float reload = 1;
    public float agroDistance = 12f;
    public float speed = 380f;
    public float attackDistance = 3f;

    public Transform attackPoint;
    
    private Transform plr;
    private Vector3 destination;
    private float lastAttack = 0;

    private Rigidbody2D rbd;
    void Start()
    {
        plr = GameObject.Find("Player").transform;
        rbd = this.GetComponent<Rigidbody2D>();
    }

    
    void Update()
    {
        Vector2 distance = this.transform.position - plr.position;
        if (distance.magnitude < agroDistance)
        {
            destination = (plr.position - rbd.transform.position) / (plr.position - rbd.transform.position).magnitude;
            rbd.velocity = (Vector3)destination * speed * Time.deltaTime;
        }
        
        if ((distance.magnitude < attackDistance) && (Time.time > reload + lastAttack))
        {
            lastAttack = Time.time;
            hit();
        }
    }
    
    public void hit()
    {
        //detect objects in range and return their layer
        Collider2D[] hitplayer = Physics2D.OverlapCircleAll(attackPoint.position, attackDistance);

        //--if layer is player, kill them
        foreach (Collider2D player in hitplayer)
        {
            controller play = player.GetComponent<controller>();
            if (play != null)
            {
                play.takeDamage(damage);
            }
        }
    }
    
    public void takeDamage(int dam)
    {
        health -= dam;
        if (health <= 0)
        {
            rbd.velocity = new Vector2(0, 0);
            //dying animation
            this.enabled = false;
        }
    }
}
