using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CEO_script : MonoBehaviour 
{
    public static CEO_script instance;
    public static GameObject[] powerups;
    public static int[] powerupSpawned;
    
    public static int money = 0;
    public static int health = 100;
    public static float speed = 0.5f;
     
    private void Awake()
    { 
        if (instance != null)
        { 
            Destroy(gameObject); 
        }
        else
        { 
            instance = this; 
            DontDestroyOnLoad(gameObject); 
        } 
    }

    private void Start() 
    { 
        powerupSpawned = new int[4];
        money = PlayerPrefs.GetInt("money", 0);
        health = PlayerPrefs.GetInt("health", 100);
        speed = PlayerPrefs.GetFloat("speed", 0.5f);
    }

    public static void transition(int newhealth)
    {
        health = newhealth;
    }

    public static void gameOver()
    {
        PlayerPrefs.SetInt("money",money);
        //other things
    }
}