
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class controller : MonoBehaviour
{
    public float speed = 1f;
    public int health = 100;
    public bool died = false;
    public Vector2 looking;
    public float firepoint = 1f;
    public float reloadTime = 0.5f;
    public float rollDuration = 0.2f;
    public float rollReload = 1f;

    public GameObject currenProj;
    public Camera maincam;
    
    private Vector2 direction = new Vector2(0, -1);
    private Vector2 dodgeDir = new Vector2(0, 0);
    private Vector2 deviation;
    private Rigidbody2D rbd;
    private float lastFireTime = 0f;
    private float lastRollTime = 0f;
    private Quaternion rot = Quaternion.Euler(0, 0, 0);
    private bool invincible = false;
    private int weaponType = 0;
    private Animator anim;
    private bool lookingRight = false;

    void Start()
    {
        rbd = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        health = CEO_script.health;
        speed = CEO_script.speed;
        lookingRight = false;
    }

    
    void FixedUpdate()
    {
        //Input
        float xaxis = Input.GetAxisRaw("Horizontal");
        float yaxis = Input.GetAxisRaw("Vertical");
        
        
        //Bullet positioning
        looking = rbd.position - (Vector2)maincam.ScreenToWorldPoint(Input.mousePosition);
        anim.SetFloat("XAxis",looking.x);
        anim.SetFloat("YAxis",-looking.y);
        looking /= (looking.magnitude/firepoint);

        if (lookingRight && looking.x > 0)
        {
            lookingRight = !lookingRight;
            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
        }
        else if (!lookingRight && looking.x < 0)
        {
            lookingRight = !lookingRight;
            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
        }
        
        
        deviation = Vector2.Perpendicular(looking);
        deviation /= 10;

        if (Input.GetButton("Fire1") && (Time.time > lastFireTime + reloadTime) && !(invincible))
        {
            FireWeapon((rbd.position-looking), rot);
        }

        direction = new Vector2(xaxis, yaxis);


        if (direction.x != 0 || direction.y != 0)
        {
            //Dash
            anim.SetBool("IsMoving",true);
            
            if (Input.GetButton("Fire2") && (Time.time > lastRollTime + rollReload))
            {
                invincible = true;
                lastRollTime = Time.time;
                dodgeDir = direction;
            }

            if (invincible)
            {
                rbd.transform.position += (Vector3)dodgeDir * (5 * speed * Time.deltaTime);
                if (Time.time > lastRollTime + rollDuration)
                {
                    invincible = false;
                }
            }
            else // Normal movement
            {
                rbd.transform.position += (Vector3) direction * (speed * Time.deltaTime);
            }
        }
        else
        {
            anim.SetBool("IsMoving",false);
        }

        if ((currenProj.name == "PeaShooter") && weaponType != 1)
        {
            anim.SetTrigger("Peas");
        }
        else if ((currenProj.name == "MachineMelon") && weaponType != 2)
        {
            anim.SetTrigger("Melon");
        }
        else if ((currenProj.name == "shotgun") && weaponType != 3)
        {
            anim.SetTrigger("Grape");
        }
        else if ((currenProj.name == "Explosive") && weaponType != 4)
        {
            anim.SetTrigger("Pine");
        }
        else if ((currenProj.name == "Sniper") && weaponType != 5)
        {
            
        }

    }

    void FireWeapon(Vector3 position, Quaternion rotation)
    {
        anim.SetTrigger("Attack");
        Debug.Log("Attack");
        GameObject bullet = Instantiate(currenProj, position, rotation);
        bullet.GetComponent<Bullet>().plr = transform;

        if (currenProj.name == "shotgun")
        {
            GameObject bullet1 = Instantiate(currenProj, position + (Vector3)deviation, rotation);
            bullet1.GetComponent<Bullet>().plr = transform;
            GameObject bullet2 = Instantiate(currenProj, position - (Vector3)deviation, rotation);
            bullet2.GetComponent<Bullet>().plr = transform;
        }
        
        reloadTime = bullet.GetComponent<Bullet>().reload;
        lastFireTime = Time.time;
    }

    public void TakeDamage(int dam)
    {
        if (!invincible)
        {
            health -= dam;
            Debug.Log("health:" + health);
            if (health <= 0)
            {
                //dying animation
                //trigger game over
                CEO_script.gameOver();
                this.enabled = false;
            }
        }
    }

    public void Destroy()
    {
        Destroy(gameObject);
    }
}